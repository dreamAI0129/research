Public SHA1 MD5 data sets
=========================

National Software Reference Library - http://www.nsrl.nist.gov/Downloads.html
