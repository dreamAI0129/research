Licenses
========

.. toctree::
   :titlesonly:

   gnu-gpl-v2.0
   cc-nc-4.0

Suricata Source Code
--------------------

The Suricata source code is licensed under version 2 of the
:doc:`gnu-gpl-v2.0`.

Suricata Documentation
----------------------

The Suricata documentation (this documentation) is licensed under the
:doc:`cc-nc-4.0`.
